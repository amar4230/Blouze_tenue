(function () {
  'use strict';
  var $ = function (s, r) { return (r || document).querySelector(s); };
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function load() {
    try { var d = JSON.parse(localStorage.getItem('bt_data')); if (d && d.products) return d; } catch (e) {}
    return JSON.parse(JSON.stringify(window.BT_DEFAULTS));
  }
  var D = load();
  function fmt(n) { return Number(n).toLocaleString('en-US') + ' أوقية'; }
  function phoneShow() { var p = D.phone; return '+' + p.slice(0, 3) + ' ' + p.slice(3, 5) + ' ' + p.slice(5, 7) + ' ' + p.slice(7, 9) + ' ' + p.slice(9); }
  function wa(text) { return 'https://wa.me/' + D.phone + (text ? '?text=' + encodeURIComponent(text) : ''); }
  function find(id) { return D.products.filter(function (p) { return p.id === id; })[0]; }
  function lines(t) { return String(t || '').split('\n').map(function (x) { return x.trim(); }).filter(Boolean); }
  function out(p) { return p.stock !== null && p.stock !== undefined && p.stock !== '' && Number(p.stock) <= 0; }
  function isTR(p) { return /ترك/.test(p.origin); }

  /* ---------- بطاقة التحكم بالمنتج (مقاس + كمية + اطلب الآن) ---------- */
  function controls(p, withLink) {
    var max = (p.stock !== null && p.stock !== '' && p.stock !== undefined) ? Number(p.stock) : 99;
    var sizes = (p.sizes || []).map(function (s) { return '<option>' + esc(s) + '</option>'; }).join('');
    return '<div class="pc" data-id="' + esc(p.id) + '">' +
      '<label>المقاس<select class="sz">' + sizes + '</select></label>' +
      '<label>الكمية<input class="qt" type="number" min="1" max="' + max + '" value="1" inputmode="numeric"></label>' +
      '<button class="btn btn-p" data-order ' + (out(p) ? 'disabled' : '') + '>' + (out(p) ? 'نفدت الكمية' : 'اطلب الآن') + '</button>' +
      (withLink ? '<a class="lnk" href="#/product/' + esc(p.id) + '">عرض التفاصيل ←</a>' : '') + '</div>';
  }
  function card(p) {
    return '<article class="card"><a class="im" href="#/product/' + esc(p.id) + '"><img loading="lazy" src="' + esc(p.img) + '" alt="' + esc(p.name + ' ' + p.origin) + '">' +
      '<span class="badge ' + (isTR(p) ? 'tr' : '') + '">' + esc(p.origin) + '</span>' + (out(p) ? '<span class="badge out">نفدت</span>' : '') + '</a>' +
      '<div class="bd"><h3>' + esc(p.name) + ' – ' + esc(p.origin) + '</h3><div class="price">' + fmt(p.price) + '</div><p class="desc">' + esc(p.desc) + '</p>' + controls(p, true) + '</div></article>';
  }
  function offersHtml() {
    return '<div class="offers">' + lines(D.offers).map(function (l) {
      var a = l.split('|');
      return '<div class="offer"><b>' + esc(a[0]) + '</b>' + esc(a[1] || '') + '</div>';
    }).join('') + '</div>';
  }

  /* ---------- الصفحات ---------- */
  var pages = {
    home: function () {
      var imgs = D.products.slice(0, 3);
      return '<section class="hero"><div class="wrap hero-in"><div><h1>Blouz Tenue</h1><div class="tag">' + esc(D.tagline) + '</div>' +
        '<p>بلوزات وتنّيات طبية ومخبرية في نواكشوط. اختر منتجك، وأرسل طلبك عبر واتساب في أي وقت.</p>' +
        '<div class="acts"><a class="btn btn-w" href="#/products">تسوق الآن</a><a class="btn btn-o" style="border-color:#fff;background:transparent;color:#fff" target="_blank" rel="noopener" href="' + wa('السلام عليكم، أريد الاستفسار عن منتجات Blouz Tenue.') + '">تواصل عبر واتساب</a></div></div>' +
        '<div class="hero-imgs">' + imgs.map(function (p) { return '<img src="' + esc(p.img) + '" alt="' + esc(p.name) + '">'; }).join('') + '</div></div></section>' +
        '<div class="wrap trust"><div>🕐 استقبال الطلبات 24 ساعة</div><div>🇲🇷 صناعة محلية وتركية</div><div>💬 الطلب مباشرة عبر واتساب</div></div>' +
        '<section class="sec" id="prods"><div class="wrap"><h2>المنتجات</h2><p class="sub">الأسعار بالأوقية، وبلد الصناعة مذكور لكل منتج.</p><div class="grid">' + D.products.map(card).join('') + '</div></div></section>' +
        '<section class="sec"><div class="wrap"><h2>العروض</h2><p class="sub">&nbsp;</p>' + offersHtml() + '</div></section>' +
        '<section class="sec"><div class="wrap"><div class="cta"><h2>هل تحتاج مساعدة في اختيار المقاس؟</h2><p>راسلنا الآن وسنرد عليك في أقرب وقت ممكن.</p><a class="btn btn-w" target="_blank" rel="noopener" href="' + wa('السلام عليكم، أحتاج مساعدة في اختيار المقاس.') + '">تواصل عبر واتساب</a></div></div></section>';
    },
    products: function () {
      return '<section class="page"><div class="wrap"><h1>جميع المنتجات</h1><div class="grid">' + D.products.map(card).join('') + '</div></div></section>';
    },
    offers: function () {
      return '<section class="page"><div class="wrap"><h1>العروض</h1>' + offersHtml() + '</div></section>';
    },
    product: function (id) {
      var p = find(id);
      if (!p) return '<section class="page"><div class="wrap"><h1>المنتج غير موجود</h1><a class="btn btn-p" href="#/products">العودة للمنتجات</a></div></section>';
      return '<section class="page"><div class="wrap"><div class="crumb"><a href="#/">الرئيسية</a> / <a href="#/products">المنتجات</a> / ' + esc(p.name) + '</div>' +
        '<div class="det"><div class="card"><div class="im"><img src="' + esc(p.img) + '" alt="' + esc(p.name + ' ' + p.origin) + '"><span class="badge ' + (isTR(p) ? 'tr' : '') + '">' + esc(p.origin) + '</span></div></div>' +
        '<div class="box"><h1 style="font-size:1.5rem">' + esc(p.name) + ' – ' + esc(p.origin) + '</h1><div class="price" style="margin:8px 0">' + fmt(p.price) + '</div>' +
        '<p>' + esc(p.desc) + '</p><p><b>بلد الصناعة:</b> ' + esc(p.origin) + '</p><p><b>المقاسات المتوفرة:</b> ' + esc((p.sizes || []).join(' ، ')) + '</p>' + controls(p, false) + '</div></div></div></section>';
    },
    about: function () {
      return '<section class="page"><div class="wrap"><h1>من نحن</h1><div class="box">' + lines(D.about).map(function (l) { return '<p>' + esc(l) + '</p>'; }).join('') + '</div></div></section>';
    },
    contact: function () {
      return '<section class="page"><div class="wrap"><h1>اتصل بنا</h1><div class="box"><p><b>الموقع:</b> نواكشوط، موريتانيا</p><p><b>واتساب / هاتف:</b> <span dir="ltr">' + phoneShow() + '</span></p><p><b>الطلبات:</b> نستقبل الرسائل على مدار 24 ساعة، والرد يكون في أقرب وقت ممكن.</p>' +
        '<a class="btn btn-w" target="_blank" rel="noopener" href="' + wa('السلام عليكم') + '">فتح واتساب</a></div></div></section>';
    },
    privacy: function () {
      return '<section class="page"><div class="wrap"><h1>سياسة الخصوصية</h1><div class="box">' + lines(D.privacy).map(function (l) { return '<p>' + esc(l) + '</p>'; }).join('') + '</div></div></section>';
    },
    delivery: function () {
      return '<section class="page"><div class="wrap"><h1>سياسة التوصيل والاستبدال</h1><div class="box">' + lines(D.delivery).map(function (l) { return '<p>' + esc(l) + '</p>'; }).join('') + '</div></div></section>';
    }
  };

  function render() {
    var h = location.hash.replace(/^#\/?/, '');
    var parts = h.split('/');
    var key = parts[0] || 'home';
    var fn = pages[key] || pages.home;
    $('#app').innerHTML = fn(parts[1]);
    $('#nav').classList.remove('open');
    var links = document.querySelectorAll('.nav a');
    for (var i = 0; i < links.length; i++) {
      var on = links[i].getAttribute('href') === '#/' + (key === 'home' ? '' : key);
      links[i].classList.toggle('on', on);
    }
    window.scrollTo(0, 0);
  }

  /* ---------- نافذة الطلب ---------- */
  function openOrder(p, size, qty) {
    var total = p.price * qty;
    var m = $('#modal');
    m.innerHTML = '<div class="mbox" role="dialog" aria-modal="true"><h3>إتمام الطلب</h3>' +
      '<div class="sum"><b>' + esc(p.name) + '</b> – ' + esc(p.origin) + '<br>المقاس: ' + esc(size) + ' | الكمية: ' + qty + '<br>سعر الوحدة: ' + fmt(p.price) + '<br><b>الإجمالي: ' + fmt(total) + '</b></div>' +
      '<form id="of" novalidate>' +
      '<label class="fld"><span>الاسم</span><input name="n" autocomplete="name" required></label>' +
      '<label class="fld"><span>رقم الهاتف</span><input name="t" type="tel" inputmode="tel" dir="ltr" autocomplete="tel" placeholder="مثال: 22 33 44 55" required></label>' +
      '<label class="fld"><span>عنوان التوصيل</span><textarea name="a" rows="2" placeholder="الحي / الشارع / أقرب معلم في نواكشوط" required></textarea></label>' +
      '<div class="err" id="oe"></div>' +
      '<div class="note">سيفتح واتساب برسالة جاهزة. <b>لا يُعدّ طلبك مسجلاً ولا مؤكداً</b> إلا بعد أن تضغط «إرسال» في واتساب ويصل الطلب إلى المتجر ويؤكده.</div>' +
      '<div class="row"><button class="btn btn-w" type="submit">إرسال الطلب عبر واتساب</button><button class="btn btn-o" type="button" id="oc">إلغاء</button></div></form></div>';
    m.hidden = false;
    $('#oc').onclick = function () { m.hidden = true; };
    m.onclick = function (e) { if (e.target === m) m.hidden = true; };
    $('#of').onsubmit = function (e) {
      e.preventDefault();
      var f = e.target, n = f.n.value.trim(), t = f.t.value.trim(), a = f.a.value.trim();
      var digits = t.replace(/\D/g, '');
      if (n.length < 2) return ($('#oe').textContent = 'اكتب اسمك من فضلك.');
      if (digits.length < 8) return ($('#oe').textContent = 'اكتب رقم هاتف صحيحاً (8 أرقام على الأقل).');
      if (a.length < 3) return ($('#oe').textContent = 'اكتب عنوان التوصيل.');
      var msg = 'السلام عليكم، أرغب في طلب:\n' +
        '🛍️ المنتج: ' + p.name + '\n🏭 بلد الصناعة: ' + p.origin + '\n📏 المقاس: ' + size + '\n🔢 الكمية: ' + qty +
        '\n💰 سعر الوحدة: ' + fmt(p.price) + '\n💵 الإجمالي: ' + fmt(total) +
        '\n\n👤 الاسم: ' + n + '\n📞 الهاتف: ' + t + '\n📍 عنوان التوصيل: ' + a +
        '\n\nأرجو تأكيد الطلب. شكراً.';
      var w = window.open(wa(msg), '_blank');
      if (!w) location.href = wa(msg);
      m.innerHTML = '<div class="mbox"><h3>تم فتح واتساب</h3><p>أرسل الرسالة في واتساب حتى يصل طلبك إلى المتجر.</p><div class="note">لم يُسجَّل طلبك بعد؛ يُسجَّل ويُؤكَّد فقط عند وصول رسالتك إلى المتجر وردّه عليها.</div><button class="btn btn-p" id="ok">حسناً</button></div>';
      $('#ok').onclick = function () { m.hidden = true; };
    };
  }

  document.addEventListener('click', function (e) {
    var b = e.target.closest && e.target.closest('[data-order]');
    if (!b) return;
    var box = b.closest('.pc'), p = find(box.getAttribute('data-id'));
    if (!p) return;
    var qty = parseInt($('.qt', box).value, 10);
    var max = $('.qt', box).max ? parseInt($('.qt', box).max, 10) : 99;
    if (!qty || qty < 1) qty = 1;
    if (qty > max) { alert('الكمية المتوفرة: ' + max); return; }
    openOrder(p, $('.sz', box).value, qty);
  });

  /* ---------- المساعد (ردود جاهزة بلا خدمات مدفوعة) ---------- */
  var chatB = $('#chatB'), chatQ = $('#chatQ');
  function say(t, who) { var d = document.createElement('div'); d.className = 'msg ' + who; d.textContent = t; chatB.appendChild(d); chatB.scrollTop = chatB.scrollHeight; }
  var answers = {
    'الأسعار': function () { return D.products.map(function (p) { return '• ' + p.name + ' – ' + p.origin + ': ' + fmt(p.price); }).join('\n'); },
    'المقاسات': function () { return 'المقاسات المتوفرة: ' + (D.products[0].sizes || []).join(' ، ') + '. إن لم تكن متأكداً من مقاسك راسلنا عبر واتساب.'; },
    'التوصيل': function () { return lines(D.delivery).slice(0, 2).join('\n'); },
    'الاستبدال': function () { return lines(D.delivery).slice(2).join('\n') || 'تواصل معنا عبر واتساب.'; },
    'كيف أطلب؟': function () { return '1) اختر المنتج والمقاس والكمية.\n2) اضغط «اطلب الآن» واكتب اسمك وهاتفك وعنوانك.\n3) سيفتح واتساب برسالة جاهزة، أرسلها ليصل الطلب إلى المتجر.\nلا يُؤكَّد الطلب إلا بعد وصول رسالتك وردّ المتجر.'; }
  };
  function chatInit() {
    say('مرحباً بك في Blouz Tenue 👋\nيسعدنا خدمتك. اختر سؤالاً من الأسفل.', 'bot');
    Object.keys(answers).forEach(function (k) {
      var b = document.createElement('button'); b.textContent = k;
      b.onclick = function () { say(k, 'me'); say(answers[k](), 'bot'); };
      chatQ.appendChild(b);
    });
    var w = document.createElement('button'); w.textContent = 'تحدث مع المتجر';
    w.onclick = function () { window.open(wa('السلام عليكم، لدي استفسار.'), '_blank'); };
    chatQ.appendChild(w);
  }
  $('#chatBtn').onclick = function () { var c = $('#chat'); c.hidden = !c.hidden; };
  $('#chatX').onclick = function () { $('#chat').hidden = true; };
  chatInit();

  $('#burger').onclick = function () { $('#nav').classList.toggle('open'); };
  $('#yr').textContent = new Date().getFullYear();
  window.addEventListener('hashchange', render);
  render();
})();
