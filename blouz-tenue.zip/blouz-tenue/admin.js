(function () {
  'use strict';
  var root = document.getElementById('root');
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function fmt(n) { return Number(n).toLocaleString('en-US') + ' أوقية'; }
  function load() { try { var d = JSON.parse(localStorage.getItem('bt_data')); if (d && d.products) return d; } catch (e) {} return JSON.parse(JSON.stringify(window.BT_DEFAULTS)); }
  var D = load();
  function save() { try { localStorage.setItem('bt_data', JSON.stringify(D)); } catch (e) { alert('تعذر الحفظ: مساحة التخزين ممتلئة (قلّل حجم الصور).'); } }
  var STATUS = ['جديد', 'مؤكد', 'تم التسليم', 'ملغى'];
  var tab = 'products', editing = null;

  function sha(s) {
    if (window.crypto && crypto.subtle) {
      return crypto.subtle.digest('SHA-256', new TextEncoder().encode('bt:' + s)).then(function (b) { return Array.prototype.map.call(new Uint8Array(b), function (x) { return ('0' + x.toString(16)).slice(-2); }).join(''); });
    }
    return Promise.resolve('p:' + btoa(unescape(encodeURIComponent(s))));
  }

  /* ---------- الدخول ---------- */
  function loginView() {
    var has = !!localStorage.getItem('bt_admin');
    root.innerHTML = '<div class="box" style="max-width:420px;margin:20px auto"><h1 style="font-size:1.4rem">' + (has ? 'تسجيل الدخول' : 'إنشاء كلمة مرور للوحة') + '</h1>' +
      (has ? '' : '<p class="desc">هذه أول مرة: اختر كلمة مرور (6 أحرف على الأقل). تُحفظ في هذا المتصفح فقط.</p>') +
      '<form id="lf"><label class="fld"><span>كلمة المرور</span><input type="password" id="pw" autocomplete="' + (has ? 'current-password' : 'new-password') + '"></label><div class="err" id="le"></div><button class="btn btn-p" style="width:100%">' + (has ? 'دخول' : 'حفظ ودخول') + '</button></form></div>';
    document.getElementById('lf').onsubmit = function (e) {
      e.preventDefault();
      var v = document.getElementById('pw').value;
      sha(v).then(function (h) {
        if (!has) { if (v.length < 6) return (document.getElementById('le').textContent = 'كلمة المرور قصيرة.'); localStorage.setItem('bt_admin', h); sessionStorage.setItem('bt_in', '1'); view(); }
        else if (h === localStorage.getItem('bt_admin')) { sessionStorage.setItem('bt_in', '1'); view(); }
        else document.getElementById('le').textContent = 'كلمة المرور غير صحيحة.';
      });
    };
  }

  /* ---------- الهيكل ---------- */
  function view() {
    if (!sessionStorage.getItem('bt_in')) return loginView();
    var names = { products: 'المنتجات', orders: 'الطلبات', sales: 'المبيعات والمخزون', settings: 'الإعدادات والنشر' };
    root.innerHTML = '<div class="tabs">' + Object.keys(names).map(function (k) { return '<button data-t="' + k + '" class="' + (tab === k ? 'on' : '') + '">' + names[k] + '</button>'; }).join('') + '<button id="lo">خروج</button></div><div id="pane"></div>';
    root.querySelectorAll('[data-t]').forEach(function (b) { b.onclick = function () { tab = b.getAttribute('data-t'); editing = null; view(); }; });
    document.getElementById('lo').onclick = function () { sessionStorage.removeItem('bt_in'); view(); };
    ({ products: products, orders: orders, sales: sales, settings: settings })[tab]();
  }
  var pane = function () { return document.getElementById('pane'); };

  /* ---------- المنتجات ---------- */
  function products() {
    if (editing !== null) return form();
    pane().innerHTML = '<div class="box"><div class="row" style="align-items:center;margin-bottom:10px"><h2 style="color:var(--bd)">المنتجات (' + D.products.length + ')</h2><button class="btn btn-p" id="add" style="flex:0 0 auto">+ إضافة منتج</button></div><div class="scroll"><table class="tbl"><tr><th></th><th>المنتج</th><th>السعر</th><th>المخزون</th><th></th></tr>' +
      D.products.map(function (p, i) {
        return '<tr><td><img src="' + esc(p.img) + '" alt=""></td><td>' + esc(p.name) + '<br><small>' + esc(p.origin) + ' | ' + esc((p.sizes || []).join(',')) + '</small></td><td>' + fmt(p.price) + '</td><td>' + (p.stock === null || p.stock === '' || p.stock === undefined ? 'غير محدد' : p.stock) + '</td><td><button class="mini" data-e="' + i + '">تعديل</button> <button class="mini d" data-d="' + i + '">حذف</button></td></tr>';
      }).join('') + '</table></div></div>';
    document.getElementById('add').onclick = function () { editing = -1; products(); };
    pane().querySelectorAll('[data-e]').forEach(function (b) { b.onclick = function () { editing = +b.getAttribute('data-e'); products(); }; });
    pane().querySelectorAll('[data-d]').forEach(function (b) {
      b.onclick = function () { var i = +b.getAttribute('data-d'); if (confirm('حذف «' + D.products[i].name + ' – ' + D.products[i].origin + '»؟')) { D.products.splice(i, 1); save(); products(); } };
    });
  }
  function form() {
    var p = editing === -1 ? { id: 'p' + Date.now(), name: '', origin: 'صناعة محلية', price: '', desc: '', img: 'assets/blouse-local.svg', sizes: ['S', 'M', 'L', 'XL', 'XXL'], stock: null } : D.products[editing];
    var img = p.img;
    pane().innerHTML = '<div class="box"><h2 style="color:var(--bd);margin-bottom:10px">' + (editing === -1 ? 'منتج جديد' : 'تعديل المنتج') + '</h2><form id="pf">' +
      '<div class="two"><label class="fld"><span>اسم المنتج</span><input name="name" value="' + esc(p.name) + '" required></label>' +
      '<label class="fld"><span>بلد الصناعة</span><input name="origin" value="' + esc(p.origin) + '" required placeholder="صناعة محلية / صناعة تركية"></label>' +
      '<label class="fld"><span>السعر (أوقية)</span><input name="price" type="number" min="0" value="' + esc(p.price) + '" required></label>' +
      '<label class="fld"><span>المخزون (اتركه فارغاً لغير محدد)</span><input name="stock" type="number" min="0" value="' + (p.stock === null || p.stock === undefined ? '' : esc(p.stock)) + '"></label></div>' +
      '<label class="fld"><span>المقاسات (مفصولة بفاصلة)</span><input name="sizes" value="' + esc((p.sizes || []).join(', ')) + '"></label>' +
      '<label class="fld"><span>الوصف</span><textarea name="desc" rows="3">' + esc(p.desc) + '</textarea></label>' +
      '<label class="fld"><span>صورة المنتج (ارفع صورة من الهاتف)</span><input type="file" id="im" accept="image/*"></label><img id="pv" src="' + esc(img) + '" alt="" style="width:120px;border-radius:12px;margin-bottom:10px">' +
      '<div class="row"><button class="btn btn-p">حفظ</button><button type="button" class="btn btn-o" id="cx">إلغاء</button></div></form></div>';
    document.getElementById('im').onchange = function (e) {
      var f = e.target.files[0]; if (!f) return;
      var r = new FileReader();
      r.onload = function () {
        var im = new Image();
        im.onload = function () {
          var s = Math.min(1, 800 / Math.max(im.width, im.height)), c = document.createElement('canvas');
          c.width = im.width * s; c.height = im.height * s; c.getContext('2d').drawImage(im, 0, 0, c.width, c.height);
          img = c.toDataURL('image/jpeg', 0.82); document.getElementById('pv').src = img;
        }; im.src = r.result;
      }; r.readAsDataURL(f);
    };
    document.getElementById('cx').onclick = function () { editing = null; products(); };
    document.getElementById('pf').onsubmit = function (e) {
      e.preventDefault(); var f = e.target;
      p.name = f.name.value.trim(); p.origin = f.origin.value.trim(); p.price = Number(f.price.value);
      p.stock = f.stock.value === '' ? null : Number(f.stock.value);
      p.sizes = f.sizes.value.split(/[,،]/).map(function (s) { return s.trim(); }).filter(Boolean);
      p.desc = f.desc.value.trim(); p.img = img;
      if (editing === -1) D.products.push(p);
      save(); editing = null; products();
    };
  }

  /* ---------- الطلبات (تسجيل يدوي بعد وصول رسالة واتساب) ---------- */
  function applyStock(o, to) {
    var p = D.products.filter(function (x) { return x.id === o.pid; })[0];
    var deduct = (to === 'مؤكد' || to === 'تم التسليم');
    if (p && p.stock !== null && p.stock !== undefined && p.stock !== '') {
      if (deduct && !o.applied) { p.stock = Math.max(0, Number(p.stock) - o.qty); o.applied = true; }
      else if (!deduct && o.applied) { p.stock = Number(p.stock) + o.qty; o.applied = false; }
    }
    o.status = to;
  }
  function orders() {
    var opts = D.products.map(function (p) { return '<option value="' + esc(p.id) + '">' + esc(p.name + ' – ' + p.origin) + '</option>'; }).join('');
    pane().innerHTML = '<div class="box" style="margin-bottom:14px"><p class="note">الطلبات تصل إلى واتساب المتجر. سجّل هنا كل طلب وصلك لمتابعته (الموقع لا يملك خادماً يحفظ الطلبات تلقائياً).</p><h2 style="color:var(--bd);margin-bottom:8px">تسجيل طلب وصل عبر واتساب</h2><form id="of">' +
      '<div class="two"><label class="fld"><span>المنتج</span><select name="pid">' + opts + '</select></label><label class="fld"><span>المقاس</span><input name="size" placeholder="M"></label>' +
      '<label class="fld"><span>الكمية</span><input name="qty" type="number" min="1" value="1"></label><label class="fld"><span>الاسم</span><input name="name"></label>' +
      '<label class="fld"><span>الهاتف</span><input name="tel" dir="ltr"></label><label class="fld"><span>العنوان</span><input name="addr"></label></div><button class="btn btn-p">إضافة الطلب</button></form></div>' +
      '<div class="box"><h2 style="color:var(--bd);margin-bottom:8px">الطلبات (' + D.orders.length + ')</h2><div class="scroll"><table class="tbl"><tr><th>التاريخ</th><th>الزبون</th><th>الطلب</th><th>الإجمالي</th><th>الحالة</th><th></th></tr>' +
      D.orders.slice().reverse().map(function (o) {
        var i = D.orders.indexOf(o);
        return '<tr><td>' + esc(o.date) + '</td><td>' + esc(o.name) + '<br><small dir="ltr">' + esc(o.tel) + '</small><br><small>' + esc(o.addr) + '</small></td><td>' + esc(o.pname) + '<br><small>' + esc(o.size) + ' × ' + o.qty + '</small></td><td>' + fmt(o.total) + '</td><td><select data-s="' + i + '">' + STATUS.map(function (s) { return '<option' + (s === o.status ? ' selected' : '') + '>' + s + '</option>'; }).join('') + '</select></td><td><button class="mini d" data-x="' + i + '">حذف</button></td></tr>';
      }).join('') + '</table></div></div>';
    document.getElementById('of').onsubmit = function (e) {
      e.preventDefault(); var f = e.target, p = D.products.filter(function (x) { return x.id === f.pid.value; })[0];
      if (!p) return;
      var q = Math.max(1, parseInt(f.qty.value, 10) || 1);
      D.orders.push({ id: 'o' + Date.now(), date: new Date().toLocaleDateString('en-GB'), pid: p.id, pname: p.name + ' – ' + p.origin, price: p.price, size: f.size.value, qty: q, total: p.price * q, name: f.name.value, tel: f.tel.value, addr: f.addr.value, status: 'جديد', applied: false });
      save(); orders();
    };
    pane().querySelectorAll('[data-s]').forEach(function (s) { s.onchange = function () { applyStock(D.orders[+s.getAttribute('data-s')], s.value); save(); orders(); }; });
    pane().querySelectorAll('[data-x]').forEach(function (b) { b.onclick = function () { var i = +b.getAttribute('data-x'); if (confirm('حذف هذا الطلب؟')) { applyStock(D.orders[i], 'ملغى'); D.orders.splice(i, 1); save(); orders(); } }; });
  }

  /* ---------- المبيعات والمخزون ---------- */
  function sales() {
    var done = D.orders.filter(function (o) { return o.status === 'تم التسليم'; });
    var conf = D.orders.filter(function (o) { return o.status === 'مؤكد'; });
    var sum = function (a) { return a.reduce(function (t, o) { return t + o.total; }, 0); };
    var by = {};
    done.forEach(function (o) { by[o.pname] = (by[o.pname] || { q: 0, t: 0 }); by[o.pname].q += o.qty; by[o.pname].t += o.total; });
    pane().innerHTML = '<div class="stats"><div><b>' + fmt(sum(done)) + '</b>مبيعات مُسلَّمة</div><div><b>' + fmt(sum(conf)) + '</b>طلبات مؤكدة قيد التسليم</div><div><b>' + D.orders.filter(function (o) { return o.status === 'جديد'; }).length + '</b>طلبات جديدة</div><div><b>' + done.length + '</b>طلبات مُسلَّمة</div></div>' +
      '<div class="box" style="margin-bottom:14px"><h2 style="color:var(--bd);margin-bottom:8px">المبيعات حسب المنتج</h2><table class="tbl"><tr><th>المنتج</th><th>القطع</th><th>المبلغ</th></tr>' +
      (Object.keys(by).map(function (k) { return '<tr><td>' + esc(k) + '</td><td>' + by[k].q + '</td><td>' + fmt(by[k].t) + '</td></tr>'; }).join('') || '<tr><td colspan="3">لا مبيعات مسلّمة بعد.</td></tr>') + '</table></div>' +
      '<div class="box"><h2 style="color:var(--bd);margin-bottom:8px">المخزون</h2><table class="tbl"><tr><th>المنتج</th><th>الكمية المتبقية</th></tr>' +
      D.products.map(function (p) { return '<tr><td>' + esc(p.name + ' – ' + p.origin) + '</td><td>' + (p.stock === null || p.stock === undefined || p.stock === '' ? 'غير محدد' : p.stock) + '</td></tr>'; }).join('') + '</table><p class="desc" style="margin-top:8px">يُخصم المخزون عند تحويل الطلب إلى «مؤكد» ويُعاد عند الإلغاء. عدّل الكميات من تبويب المنتجات.</p></div>';
  }

  /* ---------- الإعدادات والنشر ---------- */
  function settings() {
    pane().innerHTML = '<div class="box" style="margin-bottom:14px"><h2 style="color:var(--bd);margin-bottom:8px">إعدادات المتجر</h2><form id="sf">' +
      '<label class="fld"><span>رقم واتساب (بصيغة دولية بدون +)</span><input name="phone" dir="ltr" value="' + esc(D.phone) + '"></label>' +
      '<label class="fld"><span>الشعار النصي</span><input name="tagline" value="' + esc(D.tagline) + '"></label>' +
      '<label class="fld"><span>العروض (سطر لكل عرض: العنوان|الوصف)</span><textarea name="offers" rows="4">' + esc(D.offers) + '</textarea></label>' +
      '<label class="fld"><span>من نحن</span><textarea name="about" rows="3">' + esc(D.about) + '</textarea></label>' +
      '<label class="fld"><span>سياسة التوصيل والاستبدال (سطر لكل نقطة)</span><textarea name="delivery" rows="5">' + esc(D.delivery) + '</textarea></label>' +
      '<label class="fld"><span>سياسة الخصوصية</span><textarea name="privacy" rows="4">' + esc(D.privacy) + '</textarea></label>' +
      '<button class="btn btn-p">حفظ الإعدادات</button> <span id="sv" class="ok"></span></form></div>' +
      '<div class="box"><h2 style="color:var(--bd);margin-bottom:8px">نشر التعديلات للزبائن</h2><p class="note">التعديلات تُحفظ في <b>هذا المتصفح</b> فقط وتظهر لك وحدك. لتظهر للزبائن: اضغط «تصدير data.js» ثم استبدل به ملف <code>data.js</code> في موقعك المنشور وأعد رفعه (انظر ملف README).</p>' +
      '<div class="row"><button class="btn btn-p" id="ex">تصدير data.js</button><button class="btn btn-o" id="rs">إعادة الضبط للافتراضي</button></div>' +
      '<hr style="margin:14px 0;border:0;border-top:1px solid var(--bm)"><form id="pw"><label class="fld"><span>تغيير كلمة المرور</span><input type="password" name="p" placeholder="كلمة جديدة (6 أحرف+)"></label><button class="btn btn-o">تغيير</button></form>' +
      '<p class="desc" style="margin-top:10px">ملاحظة أمنية: كلمة المرور تحمي اللوحة في هذا المتصفح فقط. لا يستطيع أحد تغيير الموقع العام من لوحة على جهاز آخر، لأن التعديلات لا تُنشر إلا بإعادة رفع data.js من حسابك.</p></div>';
    document.getElementById('sf').onsubmit = function (e) {
      e.preventDefault(); var f = e.target;
      var ph = f.phone.value.replace(/\D/g, ''); if (ph.length < 8) return alert('رقم واتساب غير صحيح.');
      D.phone = ph; ['tagline', 'offers', 'about', 'delivery', 'privacy'].forEach(function (k) { D[k] = f[k].value; });
      save(); document.getElementById('sv').textContent = 'تم الحفظ ✓';
    };
    document.getElementById('ex').onclick = function () {
      var pub = JSON.parse(JSON.stringify(D)); pub.orders = [];
      var blob = new Blob(['/* تم التصدير من لوحة التحكم */\nwindow.BT_DEFAULTS = ' + JSON.stringify(pub, null, 2) + ';\n'], { type: 'text/javascript' });
      var a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = 'data.js'; document.body.appendChild(a); a.click(); a.remove();
    };
    document.getElementById('rs').onclick = function () { if (confirm('سيُمسح كل ما عدّلته في هذا المتصفح بما فيه الطلبات المسجلة. متابعة؟')) { localStorage.removeItem('bt_data'); D = load(); view(); } };
    document.getElementById('pw').onsubmit = function (e) {
      e.preventDefault(); var v = e.target.p.value; if (v.length < 6) return alert('كلمة المرور قصيرة.');
      sha(v).then(function (h) { localStorage.setItem('bt_admin', h); e.target.reset(); alert('تم تغيير كلمة المرور.'); });
    };
  }

  view();
})();
